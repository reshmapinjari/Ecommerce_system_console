﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Ecommerce_System.Helpers
{
    public enum PurposeOfReturn
    {
        UnsatiSfactoryProduct, WrongProductShipped, WrongProductOrdered, DefectiveProduct
    }
}
