﻿using System;

namespace Ecommerce_System.Helpers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
