﻿using System;
using System.Collections.Generic;
using System.Text;
using Ecommerce_System.Contracts.DALContracts;
using Ecommerce_System.Entities;
using Ecommerce_System.Exceptions;
using Ecommerce_System.Helpers;

namespace Ecommerce_System.DataAccessLayer
{/// <summary>
/// views Customer reports
/// </summary>
    public class ViewCustomerReportsDAL : IDisposable
    {
        public void Dispose()
        {
           
        }
    }
}
