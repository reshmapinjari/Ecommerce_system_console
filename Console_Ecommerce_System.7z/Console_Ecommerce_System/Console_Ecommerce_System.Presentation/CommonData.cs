﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Ecommerce_System.Entities;
using Ecommerce_System.Helpers;

namespace Ecommerce_System.Presentation
{
    public static class CommonData
    {
        public static IUser CurrentUser { get; set; }
        public static UserType CurrentUserType { get; set; }
    }
}