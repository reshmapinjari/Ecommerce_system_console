﻿using System.Collections.Generic;
using Ecommerce_System.Entities;
/// <summary>
/// Developed by sravani
/// </summary>
namespace Ecommerce_System.Contracts.DALContracts
{
    //public abstract class ViewCustomerReportsDALBase
    //{
    //    public static List<ViewSalesReports> viewSales = new List<ViewSalesReports>();
    //}
}
