﻿using System;
using System.Threading.Tasks;
using Ecommerce_System.Entities;
/// <summary>
/// developed by sravani
/// </summary>
namespace Ecommerce_System.Contracts
{
    public interface IAdminBL : IDisposable
    {
        Task<Admin> GetAdminByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateAdminBL(Admin updateAdmin);
        Task<bool> UpdateAdminPasswordBL(Admin updateAdmin);
        Task<Admin> GetAdminByAdminEmailBL(string Email);
    }
}