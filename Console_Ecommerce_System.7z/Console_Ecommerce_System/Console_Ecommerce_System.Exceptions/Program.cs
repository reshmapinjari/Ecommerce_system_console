﻿using System;

namespace Ecommerce_System.Exceptions
{
    public class Ecommerce_SystemException : ApplicationException
    {
        ///constructors
        public Ecommerce_SystemException() : base()
        {
        }

        public Ecommerce_SystemException(string message) : base(message)
        {
        }

        public Ecommerce_SystemException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
